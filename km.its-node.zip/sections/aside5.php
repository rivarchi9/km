<aside class="main-aside col-xl-4 col-lg-4 col-md-4 col-sm-12 col-xs-12">
  <div class="section-gray layout outer-aside">
    <div class="aside-branding no-mobile">
      <a href="#"><img src="/app/img/content/a1.jpg" alt=""></a>
    </div>
    <div class="aside-item ">
      <div class="aside__title">АКТЕРСКИЕ АГЕНТСТВА</div>
      <div class="row-table-aside">
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">Жар-птица</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">Startup Project</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">Талантино</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">Агни Кино</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">Лены Хван</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">Лучший кастинг</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">Sevensense</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">Аг-во Бочаровой</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">Март</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">БЕРЕГ</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">London</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">Товарищ-во «КВ»</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">Киногород</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">VBG Cast</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">Аг-во Лапшиной</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">Август</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">Casting-cinema</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">GM Consulting & Production</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
        <div class="table-aside-item">
          <div class="table-aside-inner-item table-aside-name"><a href="#">МАКС</a></div>
          <div class="table-aside-inner-item table-aside-value">315</div>
          <div class="table-aside-inner-item table-aside-value2">218</div>
        </div>
      </div>
    </div>
    <div class="aside no-mobile">
      <div class="inner-aside">
        <div class="aside-item ">
          <div class="aside__title">Промо</div>
          <div class="row-posters__image">
            <a href="#">
              <div class="image-shadow-poster posters__image">
                <img alt="" src="app/img/content/as1.jpg" class="parent responsive-image image-prewiew" data-src-d="app/img/content/as1.jpg" data-src-t="app/img/content/as1.jpg" data-src-m="app/img/content/as1.jpg">
              </div>
            </a>
          </div>
          <div class="bxslider-part-title"><a href="#">АЛЕКСАНДР ГОЛОВИН</a></div>
        </div>
      </div>
    </div>
    <div class="dop-aside">
      <div class="dop-aside__item outer-dop-aside__banner">
        <div class="dop-aside__banner">
          <a href="#"><img alt="" src="#" class="responsive-image" data-src-d="app/img/content/12.jpg" data-src-t="app/img/content/12.jpg" data-src-m=""></a>
        </div>
      </div>
    </div>
  </div>
</aside>
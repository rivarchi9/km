<ul class="nav-content-list clear nav-content-list-actor">
	<div class="mobile__select my-select">
    <span class="result">КИНО</span>
    <ul class="result-list">
      <li class="nav-content-item active"><a href="actor.php">Фильмография</a></li>
		  <li class="nav-content-item default"><a href="actor_otziv.php">Отзывы</a></li>
		  <li class="nav-content-item default"><a href="actor_photo.php">Фото <span class="number">45</span></a></li>
		  <li class="nav-content-item default"><a href="actor_wall.php">Обои <span class="number">11</span></a></li>
		  <li class="nav-content-item default"><a href="actor_box.php">Кадры <span class="number">616</span></a></li>
		  <li class="nav-content-item default"><a href="actor_awards.php">Награды</a></li>
		  <li class="nav-content-item default"><a href="actor_news.php">Новости <span class="number">142</span></a></li>
		  <li class="nav-content-item-add default"><a href="actor_news.php">Смотреть <span class="number">22</span></a></li>
    </ul>
  </div>
  <li class="nav-content-item"><a href="actor.php">Фильмография</a></li>
  <li class="nav-content-item"><a href="actor_otziv.php">Отзывы</a></li>
  <li class="nav-content-item"><a href="actor_photo.php">Фото <span class="number">45</span></a></li>
  <li class="nav-content-item"><a href="actor_wall.php">Обои <span class="number">11</span></a></li>
  <li class="nav-content-item"><a href="actor_box.php">Кадры <span class="number">616</span></a></li>
  <li class="nav-content-item"><a href="actor_awards.php">Награды</a></li>
  <li class="nav-content-item"><a href="actor_news.php">Новости <span class="number">142</span></a></li>
  <li class="nav-content-item-add"><a href="actor_news.php">Смотреть <span class="number">22</span></a></li>
</ul>
<div class="footer">
  <div class="wrap">
    <div class="inner-footer">
      <a href="#" class="footer-sticker button button2">КАСТИНГ-БАЗА</a>
      <div class="copy-paste">ИСПОЛЬЗОВАНИЕ МАТЕРИАЛОВ САЙТА ВОЗМОЖНО ТОЛЬКО С РАЗРЕШЕНИЯ РЕДАКЦИИ. ГИПЕРССЫЛКА НА САЙТ ОБЯЗАТЕЛЬНА</div>
      <div class="mail"><a href="mailto:INFO@KINOMANIA.RU">INFO@KINOMANIA.RU</a></div>
      <div class="footer-nav">
        <div class="outer-footer-nav-list">
          <a href="#">СМОТРЕТЬ</a>
          <ul class="footer-nav-list">
            <li><a href="#">АФИША</a></li>
            <li><a href="#">СКОРО В КИНО</a></li>
            <li><a href="#">ТВ</a></li>
            <li><a href="#">ОНЛАЙН</a></li>
            <li><a href="#">SHORTЫ</a></li>
          </ul>
        </div>
        <div class="outer-footer-nav-list">
          <a href="#">ЧИТАТЬ</a>
          <ul class="footer-nav-list">
            <li><a href="#">НОВОСТИ</a></li>
            <li><a href="#">ИНТЕРВЬЮ</a></li>
            <li><a href="#">РЕЦЕНЗИИ</a></li>
            <li><a href="#">БЛОГИ</a></li>
            <li><a href="#">ПРЕССА</a></li>
            <li><a href="#">ФОРУМ</a></li>
          </ul>
        </div>
        <div class="outer-footer-nav-list">
          <a href="#">АРТКИНОМАНИЯ</a>
          <ul class="footer-nav-list">
            <li><a href="#">ФЕСТИВАЛИ И ПРЕМИИ</a></li>
            <li><a href="#">BOOM!</a></li>
            <li><a href="#">СЦЕНАРИИ</a></li>
          </ul>
        </div>
        <div class="outer-footer-nav-list">
          <a href="#">МЕДИА</a>
          <ul class="footer-nav-list">
            <li><a href="#">ТРЕЙЛЕРЫ</a></li>
            <li><a href="#">ПОСТЕРЫ</a></li>
            <li><a href="#">САУНДТРЕКИ</a></li>
            <li><a href="#">ФОТО</a></li>
            <li><a href="#">ОБОИ (ФИЛЬМЫ)</a></li>
            <li><a href="#">ОБОИ (АКТЕРЫ)</a></li>
            <li><a href="#">ОБОИ (АКТРИСЫ)</a></li>
          </ul>
        </div>
        <div class="outer-footer-nav-list">
          <a href="#">ЛУЧШИЕ ФИЛЬМЫ</a>
          <ul class="footer-nav-list">
            <li><a href="#">РЕЙТИНГ КИНОМАНИИ</a></li>
            <li><a href="#">ПОДБОРКИ</a></li>
            <li><a href="#">БОКС-ОФИС</a></li>
          </ul>
        </div>
      </div>
      <div class="outer-social clear">
        <ul class="social-list social-list--horizontal">
          <li class="vk"><a href="#"><span class="number">856</span></a></li>
          <li class="fb"><a href="#"><span class="number">856</span></a></li>
          <li class="ok"><a href="#"><span class="number">856</span></a></li>
          <li class="pinterest"><a href="#"><span class="number">856</span></a></li>
        </ul>
      </div>
      <div class="copyright">© 2000—2016, KINOMANIA.RU</div>
      <div class="metrica"><img alt="" src="app/img/icon/ya.png"></div>
      <div class="planeta-inform"><a href="#"><img alt="" src="app/img/icon/pi.png"></a></div>
    </div>
  </div>
</div>
<div class="nav-content">
  <h1 class="pagetitle mini__pagetitle"><?php echo $loginUser; ?></h1>
  <div class="nav-list">
    <ul>
      <li><a href="#"></a></li>
    </ul>
  </div>
</div>
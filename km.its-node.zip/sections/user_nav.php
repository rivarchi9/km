<ul class="nav-content-list clear">
  <div class="mobile__select my-select">
    <span class="result">КИНО</span>
    <ul class="result-list">
      <li class="nav-content-item active"><a href="user.php">Профиль</a></li>
      <li class="nav-content-item no-active"><span>Рецензии</span></li>
      <li class="nav-content-item no-active"><span>Отзывы</span></li>
      <li class="nav-content-item"><a href="userComments.php">Комментарии <span class="number">38</span></a></li>
      <li class="nav-content-item"><a href="userRaiting.php">Оценки <span class="number">8</span></a></li>
      <li class="nav-content-item"><a href="userFilms.php">Фильмы <span class="number">4</span></a></li>
      <li class="nav-content-item"><a href="userPeople.php">Персоналии <span class="number">4</span></a></li>
      <li class="nav-content-item"><a href="userSetting.php">Настройки</a></li>
    </ul>
  </div>
  <li class="nav-content-item active"><a href="user.php">Профиль</a></li>
  <li class="nav-content-item no-active"><span>Рецензии</span></li>
  <li class="nav-content-item no-active"><span>Отзывы</span></li>
  <li class="nav-content-item"><a href="userComments.php">Комментарии <span class="number">38</span></a></li>
  <li class="nav-content-item"><a href="userRaiting.php">Оценки <span class="number">8</span></a></li>
  <li class="nav-content-item"><a href="userFilms.php">Фильмы <span class="number">4</span></a></li>
  <li class="nav-content-item"><a href="userPeople.php">Персоналии <span class="number">4</span></a></li>
  <li class="nav-content-item"><a href="userSetting.php">Настройки</a></li>
</ul>